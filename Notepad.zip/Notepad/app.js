var express = require('express');
var app = express();

path = require('path');
//console.log(path);
var router = express.Router();
var bodyParser = require('body-parser');
request = require('request');
config = require('config');
mongoose = require('mongoose');
relationship = require("mongoose-relationship");
var swaggerJSDoc = require('swagger-jsdoc');
HttpStatus = require('http-status-codes');

app.use(bodyParser.urlencoded({ extended: true }));
//app.use(bodyParser.json({ limit: '5mb' }));

var mongoConnection = 'mongodb://' + config.mongodbConfig.host + ':' + config.mongodbConfig.port + "/" + config.mongodbConfig.dbName;
mongoose.connect(mongoConnection, { useNewUrlParser: true });

db = mongoose.connection;
db.on('error', console.error.bind(console, 'Mongodb Not Connected')); 
db.once('open', function () {
    console.log("Database connected using ", mongoConnection);
    console.log("Application is up and running in http://" + config.projectSetup.host + ":" + config.projectSetup.port);
});

var swaggerDefinition = {
    info: {
        title: 'Notepad API',
        version: '1.0.0',
        description: 'Describing a basic RESTful API with Swagger',
    },
    host: config.projectSetup.apiUrl,
    basePath: '/',
};

var options = {
    swaggerDefinition: swaggerDefinition,
    apis: ['./routes/*.js'],
};

var swaggerSpec = swaggerJSDoc(options);
app.get('/swagger.json', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    res.send(swaggerSpec);
});

notepadModel=require('./model/notepadModel');

notepadRouter=require('./route/notepadRoute');

app.use('/notepad',notepadRouter);

app.use(express.static(path.join(__dirname, 'public')));

module.exports = app;
