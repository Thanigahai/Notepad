Schema = mongoose.Schema;
ObjectId = Schema.ObjectId;


UserSchema=new Schema({

    email:{
        type:String,
        unique:true,
        trim:true,
        required:true
    },

    username:{
        type:String,
        required:true,
        trim:true
    },

    password:{
        type:String,
        required:true,
    }
});

var notepadModel = mongoose.model('notepad',UserSchema);

function model() {
    return notepadModel;
}

